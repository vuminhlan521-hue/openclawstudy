// OpenClaw 轻松学 - 主要交互脚本

document.addEventListener('DOMContentLoaded', function() {
    // 移动端菜单切换
    initMobileMenu();
    
    // FAQ 手风琴效果
    initFaqAccordion();
    
    // 平滑滚动
    initSmoothScroll();
    
    // 导航栏滚动效果
    initNavbarScroll();
});

/**
 * 移动端菜单切换
 */
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (!menuBtn || !navLinks) return;
    
    menuBtn.addEventListener('click', function() {
        navLinks.classList.toggle('active');
        
        // 切换按钮图标
        if (navLinks.classList.contains('active')) {
            menuBtn.textContent = '✕';
            // 添加移动端菜单样式
            navLinks.style.cssText = `
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 70px;
                left: 0;
                right: 0;
                background: white;
                padding: 20px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                z-index: 99;
            `;
        } else {
            menuBtn.textContent = '☰';
            navLinks.style.display = '';
        }
    });
    
    // 点击链接后关闭菜单
    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
            navLinks.style.display = '';
            menuBtn.textContent = '☰';
        });
    });
}

/**
 * FAQ 手风琴效果
 */
function initFaqAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        if (!question) return;
        
        question.addEventListener('click', function() {
            // 切换当前项
            const isActive = item.classList.contains('active');
            
            // 关闭所有项（可选：如果希望同时只打开一个，取消下面注释）
            // faqItems.forEach(i => i.classList.remove('active'));
            
            // 切换当前项状态
            if (isActive) {
                item.classList.remove('active');
            } else {
                item.classList.add('active');
            }
        });
    });
}

/**
 * 平滑滚动
 */
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (!targetElement) return;
            
            e.preventDefault();
            
            const headerOffset = 80;
            const elementPosition = targetElement.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
            
            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        });
    });
}

/**
 * 导航栏滚动效果
 */
function initNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;
    
    let lastScroll = 0;
    
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        
        // 添加/移除阴影
        if (currentScroll > 10) {
            navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
        } else {
            navbar.style.boxShadow = '0 2px 10px rgba(0,0,0,0.05)';
        }
        
        // 可选：滚动时隐藏/显示导航栏
        // if (currentScroll > lastScroll && currentScroll > 100) {
        //     navbar.style.transform = 'translateY(-100%)';
        // } else {
        //     navbar.style.transform = 'translateY(0)';
        // }
        
        lastScroll = currentScroll;
    });
}

/**
 * 复制代码功能
 */
function copyCode(button) {
    const codeBlock = button.nextElementSibling;
    if (!codeBlock) return;
    
    const code = codeBlock.textContent;
    
    navigator.clipboard.writeText(code).then(() => {
        const originalText = button.textContent;
        button.textContent = '✓ 已复制';
        button.style.background = '#10B981';
        
        setTimeout(() => {
            button.textContent = originalText;
            button.style.background = '';
        }, 2000);
    }).catch(err => {
        console.error('复制失败:', err);
        button.textContent = '复制失败';
        setTimeout(() => {
            button.textContent = '复制';
        }, 2000);
    });
}

/**
 * 检查清单交互
 */
document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        const label = this.closest('label');
        if (this.checked) {
            label.style.opacity = '0.6';
            label.querySelector('div strong').style.textDecoration = 'line-through';
        } else {
            label.style.opacity = '1';
            label.querySelector('div strong').style.textDecoration = 'none';
        }
        
        // 保存到 localStorage
        saveCheckboxState();
    });
});

function saveCheckboxState() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"');
    const state = Array.from(checkboxes).map(cb => cb.checked);
    localStorage.setItem('openclaw_checklist', JSON.stringify(state));
}

function loadCheckboxState() {
    const saved = localStorage.getItem('openclaw_checklist');
    if (!saved) return;
    
    const state = JSON.parse(saved);
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    
    checkboxes.forEach((cb, index) => {
        if (state[index]) {
            cb.checked = true;
            const label = cb.closest('label');
            if (label) {
                label.style.opacity = '0.6';
                const strong = label.querySelector('div strong');
                if (strong) strong.style.textDecoration = 'line-through';
            }
        }
    });
}

// 页面加载时恢复检查清单状态
document.addEventListener('DOMContentLoaded', loadCheckboxState);

/**
 * 滚动动画
 */
function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('.feature-card, .audience-card, .example-card, .path-step');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// 初始化滚动动画
document.addEventListener('DOMContentLoaded', initScrollAnimations);

/**
 * 工具提示
 */
function showTooltip(element, message) {
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = message;
    tooltip.style.cssText = `
        position: absolute;
        background: #1A1A2E;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
        z-index: 1000;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.3s;
    `;
    
    document.body.appendChild(tooltip);
    
    const rect = element.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';
    
    requestAnimationFrame(() => {
        tooltip.style.opacity = '1';
    });
    
    setTimeout(() => {
        tooltip.style.opacity = '0';
        setTimeout(() => tooltip.remove(), 300);
    }, 2000);
}

/**
 * 搜索功能（用于 FAQ 页面）
 */
function initFaqSearch() {
    const searchInput = document.querySelector('.faq-search');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        const faqItems = document.querySelectorAll('.faq-item');
        
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question').textContent.toLowerCase();
            const answer = item.querySelector('.faq-answer').textContent.toLowerCase();
            
            if (question.includes(query) || answer.includes(query)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', initFaqSearch);

// 控制台欢迎信息
console.log('%c🦞 OpenClaw 轻松学', 'font-size: 24px; font-weight: bold; color: #FF6B35;');
console.log('%c让 AI 真正成为你的助手', 'font-size: 14px; color: #5A5A6E;');
console.log('%c访问 https://github.com/openclaw/openclaw 了解更多', 'font-size: 12px; color: #8A8A9E;');
