#!/bin/bash

# OpenClaw 学习沙箱启动脚本
# 用法: ./start.sh [选项]

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 显示帮助
show_help() {
    echo -e "${BLUE}OpenClaw 学习沙箱启动脚本${NC}"
    echo ""
    echo "用法: ./start.sh [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help          显示帮助信息"
    echo "  -d, --detach        后台模式运行"
    echo "  -f, --fresh         清除数据后重新启动"
    echo "  -s, --stop          停止沙箱环境"
    echo "  -r, --restart       重启沙箱环境"
    echo "  -l, --logs          查看日志"
    echo "  -c, --clean         清理所有数据（谨慎使用）"
    echo "  --with-openrouter   使用 OpenRouter（推荐，无需翻墙）"
    echo ""
    echo "示例:"
    echo "  ./start.sh                    # 前台启动"
    echo "  ./start.sh -d                 # 后台启动"
    echo "  ./start.sh -f --with-openrouter  # 全新启动并使用 OpenRouter"
    echo ""
}

# 检查依赖
check_dependencies() {
    echo -e "${BLUE}🔍 检查依赖...${NC}"
    
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}❌ 未安装 Docker${NC}"
        echo "请访问 https://docs.docker.com/get-docker/ 安装 Docker"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        echo -e "${RED}❌ 未安装 Docker Compose${NC}"
        echo "请访问 https://docs.docker.com/compose/install/ 安装 Docker Compose"
        exit 1
    fi
    
    # 检查 Docker 是否运行
    if ! docker info &> /dev/null; then
        echo -e "${RED}❌ Docker 未运行${NC}"
        echo "请启动 Docker 服务后再试"
        exit 1
    fi
    
    echo -e "${GREEN}✅ 依赖检查通过${NC}"
}

# 创建必要的目录
setup_directories() {
    echo -e "${BLUE}📁 创建目录结构...${NC}"
    
    mkdir -p data workspace logs
    mkdir -p workspace/{examples,projects,downloads}
    
    # 创建示例文件
    if [ ! -f "workspace/welcome.md" ]; then
        cat > workspace/welcome.md << 'EOF'
# 欢迎使用 OpenClaw 学习沙箱！

这是一个安全的环境，你可以在这里学习和体验 OpenClaw 的强大功能。

## 🎯 快速开始

1. **AI 对话** - 与 AI 助手进行自然语言交互
2. **文件管理** - 在 workspace 目录中创建和管理文件
3. **自动化任务** - 设置定时任务和自动化流程
4. **浏览器控制** - 体验网页自动化操作（模拟）

## 📚 学习资源

- 输入 `help` 查看可用命令
- 访问 http://localhost:8080 查看沙箱管理界面
- 查看 examples 目录中的示例项目

## ⚠️ 注意事项

- 这是一个沙箱环境，数据会在重启后保留
- 不要在此环境中存储敏感信息
- 如需全新开始，使用 `./start.sh -f` 重新启动

祝你学习愉快！
EOF
    fi
    
    echo -e "${GREEN}✅ 目录创建完成${NC}"
}

# 配置环境变量
setup_env() {
    echo -e "${BLUE}⚙️  配置环境...${NC}"
    
    # 检查 .env 文件
    if [ ! -f ".env" ]; then
        cat > .env << EOF
# OpenClaw 沙箱环境配置
NODE_ENV=production
SANDBOX_MODE=true
DEMO_MODE=true

# AI 配置（使用 OpenRouter 作为默认）
# 如需使用其他模型，请修改 config/openclaw.json
OPENROUTER_API_KEY=${OPENROUTER_API_KEY:-}

# 数据库配置
POSTGRES_USER=sandbox
POSTGRES_PASSWORD=sandbox123
POSTGRES_DB=openclaw_demo

# 日志级别
LOG_LEVEL=info
EOF
        echo -e "${YELLOW}⚠️  已创建默认 .env 文件${NC}"
        echo "如需配置 AI API Key，请编辑 .env 文件"
    fi
    
    # 加载环境变量
    set -a
    source .env
    set +a
    
    echo -e "${GREEN}✅ 环境配置完成${NC}"
}

# 启动沙箱
start_sandbox() {
    local detach=$1
    
    echo -e "${BLUE}🚀 启动 OpenClaw 学习沙箱...${NC}"
    
    if [ "$detach" = true ]; then
        docker-compose up -d
        echo -e "${GREEN}✅ 沙箱已在后台启动${NC}"
        echo ""
        echo "访问地址:"
        echo "  - 沙箱管理界面: http://localhost:8080"
        echo "  - OpenClaw Web: http://localhost:3001"
        echo "  - 文件浏览器: http://localhost:8081"
        echo ""
        echo "查看日志: ./start.sh -l"
        echo "停止沙箱: ./start.sh -s"
    else
        echo -e "${YELLOW}💡 按 Ctrl+C 停止沙箱${NC}"
        echo ""
        docker-compose up
    fi
}

# 停止沙箱
stop_sandbox() {
    echo -e "${BLUE}🛑 停止 OpenClaw 学习沙箱...${NC}"
    docker-compose down
    echo -e "${GREEN}✅ 沙箱已停止${NC}"
}

# 重启沙箱
restart_sandbox() {
    echo -e "${BLUE}🔄 重启 OpenClaw 学习沙箱...${NC}"
    docker-compose restart
    echo -e "${GREEN}✅ 沙箱已重启${NC}"
}

# 查看日志
show_logs() {
    echo -e "${BLUE}📋 查看日志（按 Ctrl+C 退出）...${NC}"
    docker-compose logs -f
}

# 清理数据
clean_data() {
    echo -e "${RED}⚠️  警告: 这将删除所有沙箱数据！${NC}"
    read -p "确定要继续吗？(yes/no): " confirm
    
    if [ "$confirm" = "yes" ]; then
        echo -e "${BLUE}🧹 清理数据...${NC}"
        docker-compose down -v
        rm -rf data/* workspace/* logs/*
        echo -e "${GREEN}✅ 数据已清理${NC}"
    else
        echo -e "${YELLOW}❌ 已取消${NC}"
    fi
}

# 全新启动
fresh_start() {
    echo -e "${BLUE}🔄 全新启动...${NC}"
    docker-compose down 2>/dev/null || true
    rm -rf data/* logs/*
    setup_directories
    start_sandbox "$1"
}

# 显示状态
show_status() {
    echo -e "${BLUE}📊 沙箱状态${NC}"
    echo ""
    docker-compose ps
    echo ""
    echo "访问地址:"
    echo "  - 沙箱管理界面: http://localhost:8080"
    echo "  - OpenClaw Web: http://localhost:3001"
    echo "  - 文件浏览器: http://localhost:8081"
}

# 主函数
main() {
    local detach=false
    local fresh=false
    local use_openrouter=false
    
    # 解析参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -d|--detach)
                detach=true
                shift
                ;;
            -f|--fresh)
                fresh=true
                shift
                ;;
            -s|--stop)
                stop_sandbox
                exit 0
                ;;
            -r|--restart)
                restart_sandbox
                exit 0
                ;;
            -l|--logs)
                show_logs
                exit 0
                ;;
            -c|--clean)
                clean_data
                exit 0
                ;;
            --status)
                show_status
                exit 0
                ;;
            --with-openrouter)
                use_openrouter=true
                shift
                ;;
            *)
                echo -e "${RED}❌ 未知选项: $1${NC}"
                show_help
                exit 1
                ;;
        esac
    done
    
    # 检查依赖
    check_dependencies
    
    # 设置目录
    setup_directories
    
    # 设置环境
    setup_env
    
    # 如果使用 OpenRouter，提示用户
    if [ "$use_openrouter" = true ]; then
        echo -e "${BLUE}🔑 OpenRouter 配置${NC}"
        echo "OpenRouter 提供统一的 API 接口，支持多种模型"
        echo "访问 https://openrouter.ai/keys 获取 API Key"
        echo ""
        
        if [ -z "$OPENROUTER_API_KEY" ]; then
            read -p "请输入 OpenRouter API Key (可选，稍后也可在 .env 中配置): " api_key
            if [ -n "$api_key" ]; then
                export OPENROUTER_API_KEY="$api_key"
                sed -i "s/OPENROUTER_API_KEY=.*/OPENROUTER_API_KEY=$api_key/" .env
            fi
        fi
    fi
    
    # 启动
    if [ "$fresh" = true ]; then
        fresh_start "$detach"
    else
        start_sandbox "$detach"
    fi
}

# 运行主函数
main "$@"
