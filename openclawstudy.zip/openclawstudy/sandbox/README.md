# OpenClaw 学习沙箱

🧪 一个完全隔离的 Docker 环境，让你可以在本地安全地体验 OpenClaw 的所有功能。

## ✨ 特性

- 🛡️ **安全隔离** - 所有操作都在容器内进行，不影响主机系统
- 🚀 **一键启动** - 一条命令即可启动完整环境
- 🔄 **随时重置** - 搞砸了？一键重置重新开始
- 📚 **配套教程** - 内置渐进式学习任务
- 🇨🇳 **国产支持** - 完全支持国产模型和 IM 接入

## 🚀 快速开始

### 前提条件

- Docker 和 Docker Compose 已安装
- 至少 4GB 可用内存

### 启动沙箱

```bash
# 1. 进入沙箱目录
cd openclawstudy/sandbox

# 2. （可选）配置 API Key
cp .env.example .env
# 编辑 .env 文件，填入你的 API Key

# 3. 启动沙箱
./start.sh
```

### 访问沙箱

启动成功后，访问以下地址：

- **沙箱管理界面**: http://localhost:8080
- **OpenClaw Web**: http://localhost:3001
- **文件浏览器**: http://localhost:8081

## 📚 学习任务

沙箱内置 5 个渐进式学习任务：

1. **基础 AI 对话** (10分钟) - 学会与 OpenClaw 进行自然语言交互
2. **文件操作** (15分钟) - 学会管理和操作文件
3. **自动化任务** (20分钟) - 学会设置定时任务
4. **网页自动化** (20分钟) - 了解浏览器控制功能
5. **综合项目** (30分钟) - 完成一个实际自动化项目

## ⚙️ 管理命令

```bash
./start.sh -d        # 后台启动
./start.sh -f        # 清除数据后重新启动
./start.sh -s        # 停止沙箱
./start.sh -r        # 重启沙箱
./start.sh -l        # 查看实时日志
./start.sh -c        # 清理所有数据（谨慎使用）
./start.sh --status  # 查看状态
```

## 🔧 配置说明

### 配置文件位置

- `config/openclaw.json` - OpenClaw 主配置
- `.env` - 环境变量（API Keys 等）
- `workspace/` - 工作空间文件
- `data/` - OpenClaw 数据

### 配置国产模型

编辑 `config/openclaw.json`：

```json
{
  "ai": {
    "provider": "zhipu",
    "model": "glm-4",
    "apiKey": "your-zhipu-api-key"
  }
}
```

支持的国产模型：智谱 GLM、Moonshot、通义千问、MiniMax、文心一言、零一万物。

## 📁 目录结构

```
sandbox/
├── docker-compose.yml      # Docker 编排配置
├── start.sh               # 启动脚本
├── nginx.conf             # Nginx 配置
├── config/                # 配置文件
│   └── openclaw.json     # OpenClaw 配置
├── workspace/            # 工作空间（持久化）
│   ├── examples/        # 示例任务
│   └── projects/        # 项目文件
├── data/                 # 数据目录（持久化）
├── www/                  # Web 管理界面
│   └── index.html
└── logs/                 # 日志目录
```

## ❓ 常见问题

### Q: 沙箱和正式安装有什么区别？

A: 沙箱是隔离的 Docker 环境，适合学习和测试；正式安装直接运行在主机上，适合生产环境。

### Q: 数据会保存吗？

A: 会。workspace/ 和 data/ 目录会映射到本地，即使容器删除数据也不会丢失。

### Q: 如何进入容器内部？

A: 运行 `docker exec -it openclaw-sandbox bash`

### Q: 启动失败怎么办？

A: 1) 检查 Docker 是否运行 2) 查看日志 `./start.sh -l` 3) 检查端口是否被占用 4) 尝试 `./start.sh -f` 重置启动

## 🔗 相关链接

- [OpenClaw 轻松学主站](../index.html)
- [国产模型接入指南](../china-models.html)
- [国产 IM 接入指南](../china-im.html)
- [常见问题](../faq.html)

## 📝 License

MIT License - 仅供学习使用
