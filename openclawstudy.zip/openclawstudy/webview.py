#!/usr/bin/env python3
"""
简易命令行网页浏览工具
用于在终端中查看网页纯文本内容
"""

import sys
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

def fetch_page(url):
    """获取网页内容"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        response.encoding = response.apparent_encoding
        return response.text
    except Exception as e:
        print(f"错误: 无法获取页面 - {e}")
        return None

def parse_content(html, base_url):
    """解析网页内容为纯文本"""
    soup = BeautifulSoup(html, 'lxml')
    
    # 移除脚本和样式
    for script in soup(['script', 'style', 'nav', 'footer']):
        script.decompose()
    
    result = []
    
    # 标题
    title = soup.find('title')
    if title:
        result.append(f"\n{'='*60}")
        result.append(f"标题: {title.get_text(strip=True)}")
        result.append(f"{'='*60}\n")
    
    # 主要标题
    for h in soup.find_all(['h1', 'h2', 'h3']):
        text = h.get_text(strip=True)
        if text:
            level = int(h.name[1])
            prefix = '  ' * (level - 1) + ['▶ ', '  ▸ ', '    • '][level - 1]
            result.append(f"\n{prefix}{text}")
    
    # 段落
    for p in soup.find_all('p'):
        text = p.get_text(strip=True)
        if text and len(text) > 10:
            result.append(f"  {text}")
    
    # 列表项
    for li in soup.find_all('li'):
        text = li.get_text(strip=True)
        if text:
            result.append(f"    · {text}")
    
    # 链接
    links = []
    for a in soup.find_all('a', href=True):
        href = a['href']
        text = a.get_text(strip=True)
        if text and href:
            full_url = urljoin(base_url, href)
            links.append((text, full_url))
    
    if links:
        result.append(f"\n\n{'-'*60}")
        result.append("页面链接:")
        result.append(f"{'-'*60}")
        for i, (text, url) in enumerate(links[:20], 1):
            result.append(f"  {i}. {text[:50]}: {url[:60]}")
    
    return '\n'.join(result)

def main():
    if len(sys.argv) < 2:
        print("用法: python3 webview.py <网址>")
        print("示例: python3 webview.py https://claw101.com/")
        sys.exit(1)
    
    url = sys.argv[1]
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    print(f"正在获取: {url}")
    print("请稍候...\n")
    
    html = fetch_page(url)
    if html:
        content = parse_content(html, url)
        print(content)
        print(f"\n{'='*60}")
        print(f"页面内容已显示完毕")
        print(f"{'='*60}")

if __name__ == '__main__':
    main()
